const express = require('express');
const Auction = require('../models/auctionModel');

const router = express.Router();

// Create Auction
router.post('/create', async (req, res) => {
    try {
        const auction = await Auction.create(req.body);
        res.status(201).json(auction);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Delete Auction
router.delete('/delete/:id', async (req, res) => {
    try {
        const deletedAuction = await Auction.findByIdAndDelete(req.params.id);
        if (!deletedAuction) return res.status(404).json({ message: "Auction not found" });
        res.json({ message: "Auction deleted successfully" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Edit Auction
router.put('/edit/:id', async (req, res) => {
    try {
        const updatedAuction = await Auction.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedAuction) return res.status(404).json({ message: "Auction not found" });
        res.json(updatedAuction);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
