const mongoose = require('mongoose');

const auctionSchema = new mongoose.Schema({
    itemName: { type: String, required: true },
    startingBid: { type: Number, required: true },
    highestBid: { type: Number, default: 0 },
    status: { type: String, enum: ['active', 'closed'], default: 'active' },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Auction', auctionSchema);
