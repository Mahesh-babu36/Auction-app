import React, { useEffect, useState } from "react";
import { getAuctions } from "../api";

const Auctions = () => {
  const [auctions, setAuctions] = useState([]);

  useEffect(() => {
    getAuctions().then((res) => setAuctions(res.data));
  }, []);

  return (
    <div>
      <h2>Available Auctions</h2>
      {auctions.map((auction) => (
        <div key={auction._id}>
          <h3>{auction.title}</h3>
          <p>{auction.description}</p>
          <p>Starting Price: ${auction.startingPrice}</p>
        </div>
      ))}
    </div>
  );
};

export default Auctions;
