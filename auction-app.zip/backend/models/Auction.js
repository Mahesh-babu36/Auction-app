const mongoose = require("mongoose");

const AuctionSchema = new mongoose.Schema({
  title: String,
  description: String,
  startingPrice: Number,
  highestBid: Number,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
}, { timestamps: true });

module.exports = mongoose.model("Auction", AuctionSchema);
