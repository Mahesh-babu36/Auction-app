const express = require("express");
const Auction = require("../models/Auction");

const router = express.Router();

router.get("/", async (req, res) => {
  const auctions = await Auction.find().populate("createdBy", "name");
  res.json(auctions);
});

router.post("/", async (req, res) => {
  const { title, description, startingPrice, userId } = req.body;
  const auction = new Auction({
    title,
    description,
    startingPrice,
    highestBid: startingPrice,
    createdBy: userId,
  });
  await auction.save();
  res.json(auction);
});

module.exports = router;
